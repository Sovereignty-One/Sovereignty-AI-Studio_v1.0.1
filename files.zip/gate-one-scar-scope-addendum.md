## SCAR Scope Addendum — Mail-Transport Layer Exclusion

**Effective:** Logged alongside AUDIT/external-mail-dependency finding

**Clarification:**

SCAR zero-tolerance policy (no Google Fonts/APIs/CDNs, no Firebase, no
Vertex AI, no Meta, no third-party cloud service in any deliverable)
governs artifacts, infrastructure, and services **deployed or controlled
by the device owner**. It does not extend to third-party organizations'
own internal mail-transport infrastructure (MX records, SMTP relays)
for domains not owned or operated by the device owner.

**Rationale:**

Sanctioned AI providers (Anthropic, OpenAI, xAI, GitHub/Microsoft) are
sanctioned at the app/model/inference layer — meaning their APIs, SDKs,
and runtime integrations are approved for use within Sovereignty-AI-Gate
and related projects. Their choice of corporate email infrastructure is
outside that scope entirely and outside the device owner's authority to
change.

**Rule going forward:**

A domain routing its own mail through Google, Microsoft, or any other
third party does **not** trigger a SCAR violation and does **not**
disqualify that provider from sanctioned status. SCAR applies to:

- Fonts, APIs, CDNs, and cloud services *embedded in deliverables*
- Runtime dependencies *pulled into the local stack*
- Model/inference providers *selected for the sanctioned list*

SCAR does **not** apply to:

- Third-party organizations' internal corporate infrastructure
- Public DNS records outside device owner's zone
- Mail transport for domains not owned/operated locally

This scope boundary prevents future false-positive escalations on
provider mail infrastructure that is unrelated to, and unreachable by,
any deliverable in this stack.
